package edu.stevens.cs522.chatserver.activities;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import edu.stevens.cs522.chatserver.R;
import edu.stevens.cs522.chatserver.async.IQueryListener;
import edu.stevens.cs522.chatserver.contracts.MessageContract;
import edu.stevens.cs522.chatserver.entities.Message;
import edu.stevens.cs522.chatserver.entities.Peer;
import edu.stevens.cs522.chatserver.managers.MessageManager;
import edu.stevens.cs522.chatserver.managers.TypedCursor;

/**
 * Created by dduggan.
 */

public class ViewPeerActivity extends Activity implements IQueryListener<Message> {

    public static final String PEER_KEY = "peer";

    private SimpleCursorAdapter messageAdapter;

    private MessageManager messageManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peer);

        Peer peer = getIntent().getParcelableExtra(PEER_KEY);
        if (peer == null) {
            throw new IllegalArgumentException("Expected peer as intent extra");
        }

        // TODO init the UI and initiate query of message database
        String[] from = new String[]{MessageContract.MESSAGE_TEXT};
        int[] to = new int[]{android.R.id.text1};
        messageAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1,
                null, from, to, 0);
        ((TextView) findViewById(R.id.view_user_name)).setText(peer.name);
        ((TextView) findViewById(R.id.view_timestamp)).setText(peer.timestamp.toString());
        ((TextView) findViewById(R.id.view_address)).setText(peer.address.getHostAddress());
        messageManager = new MessageManager(this);
        messageManager.getMessagesByPeerAsync(peer, this);
        ((ListView) findViewById(R.id.view_messages)).setAdapter(messageAdapter);
    }

    @Override
    public void handleResults(TypedCursor<Message> results) {
        // TODO
        messageAdapter.swapCursor(results.getCursor());
    }

    @Override
    public void closeResults() {
        // TODO
        messageAdapter.swapCursor(null);
    }


}
